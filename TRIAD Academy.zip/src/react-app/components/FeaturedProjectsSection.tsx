import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star, ExternalLink, Github } from 'lucide-react';

export default function FeaturedProjectsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const featuredProjects = [
    {
      id: 1,
      title: "AI-Powered Medical Diagnosis Assistant",
      description: "Advanced machine learning system that assists doctors in diagnosing diseases with 94% accuracy using medical imaging and patient data.",
      longDescription: "This groundbreaking project combines computer vision and natural language processing to analyze medical scans and patient symptoms, providing diagnostic suggestions to healthcare professionals.",
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=600&h=400&fit=crop",
      techStack: ["Python", "TensorFlow", "OpenCV", "FastAPI", "React"],
      student: "Dr. Priya Patel",
      studentImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
      category: "AI & ML",
      github: "#",
      demo: "#",
      impact: "Deployed in 3 hospitals, assisting 500+ diagnoses monthly"
    },
    {
      id: 2,
      title: "Quantum Cryptography Communication Network",
      description: "Secure communication system using quantum key distribution for unbreakable encryption in financial transactions.",
      longDescription: "Revolutionary approach to cybersecurity leveraging quantum mechanics principles to create theoretically unbreakable encrypted communication channels for banking and government use.",
      image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&h=400&fit=crop",
      techStack: ["Qiskit", "Python", "Cryptography", "WebRTC", "Blockchain"],
      student: "Alex Quantum",
      studentImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
      category: "Future Tech",
      github: "#",
      demo: "#",
      impact: "Patent pending, partnered with 2 fintech companies"
    },
    {
      id: 3,
      title: "Autonomous Drone Traffic Management",
      description: "AI-controlled system for managing autonomous drone traffic in urban environments, preventing collisions and optimizing flight paths.",
      longDescription: "Smart city infrastructure project that coordinates thousands of delivery drones using real-time weather data, no-fly zones, and machine learning prediction algorithms.",
      image: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=600&h=400&fit=crop",
      techStack: ["ROS", "Python", "Computer Vision", "AWS IoT", "Machine Learning"],
      student: "Marcus Rodriguez",
      studentImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
      category: "Systems",
      github: "#",
      demo: "#",
      impact: "Tested by city of San Francisco, 99.7% collision avoidance"
    }
  ];

  // Auto-advance carousel
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === featuredProjects.length - 1 ? 0 : prevIndex + 1
      );
    }, 8000);
    
    return () => clearInterval(timer);
  }, [featuredProjects.length]);

  const nextProject = () => {
    setCurrentIndex(currentIndex === featuredProjects.length - 1 ? 0 : currentIndex + 1);
  };

  const prevProject = () => {
    setCurrentIndex(currentIndex === 0 ? featuredProjects.length - 1 : currentIndex - 1);
  };

  const currentProject = featuredProjects[currentIndex];

  return (
    <section className="py-20 bg-arctic-white relative overflow-hidden">
      {/* Pyramid watermark */}
      <div className="absolute inset-0 opacity-5">
        <svg viewBox="0 0 400 400" className="w-full h-full">
          <polygon points="200,50 100,350 300,350" stroke="#1F3C5B" strokeWidth="2" fill="none" />
          <polygon points="200,100 150,300 250,300" stroke="#1F3C5B" strokeWidth="2" fill="none" />
          <polygon points="200,150 175,250 225,250" stroke="#1F3C5B" strokeWidth="2" fill="none" />
        </svg>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
            Spotlight Projects
          </h2>
          <p className="font-inter text-lg text-charcoal-gray max-w-2xl mx-auto">
            Exceptional innovations that showcase the pinnacle of student achievement and real-world impact.
          </p>
        </div>

        {/* Featured Project Slider */}
        <div className="relative">
          <div className="bg-white rounded-2xl shadow-2xl border-2 border-sky-cyan/20 glow-cyan overflow-hidden fade-in">
            <div className="grid lg:grid-cols-2 gap-0">
              {/* Project Image */}
              <div className="relative h-80 lg:h-96 overflow-hidden">
                <img 
                  src={currentProject.image}
                  alt={currentProject.title}
                  className="w-full h-full object-cover"
                />
                
                {/* Image Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-steel-navy/70 via-transparent to-transparent"></div>
                
                {/* Category Badge */}
                <div className="absolute top-6 right-6 bg-sky-cyan text-steel-navy px-4 py-2 rounded-full font-montserrat font-semibold">
                  {currentProject.category}
                </div>
                
                {/* Star Icon */}
                <div className="absolute top-6 left-6 w-12 h-12 bg-white/20 backdrop-blur-lg rounded-full flex items-center justify-center">
                  <Star className="w-6 h-6 text-sky-cyan fill-current" />
                </div>
              </div>
              
              {/* Project Details */}
              <div className="p-8 lg:p-12 flex flex-col justify-between">
                {/* Content */}
                <div>
                  {/* Title */}
                  <h3 className="font-montserrat font-bold text-2xl lg:text-3xl text-steel-navy mb-4">
                    {currentProject.title}
                  </h3>
                  
                  {/* Description */}
                  <p className="font-inter text-charcoal-gray mb-4 leading-relaxed">
                    {currentProject.description}
                  </p>
                  
                  {/* Long Description */}
                  <p className="font-inter text-sm text-charcoal-gray/70 mb-6 leading-relaxed">
                    {currentProject.longDescription}
                  </p>
                  
                  {/* Impact */}
                  <div className="bg-sky-cyan/10 border border-sky-cyan/20 rounded-xl p-4 mb-6">
                    <p className="font-inter text-sm text-steel-navy">
                      <span className="font-semibold">Impact:</span> {currentProject.impact}
                    </p>
                  </div>
                  
                  {/* Tech Stack */}
                  <div className="mb-6">
                    <h4 className="font-montserrat font-semibold text-steel-navy mb-3">Technologies Used</h4>
                    <div className="flex flex-wrap gap-2">
                      {currentProject.techStack.map((tech, index) => (
                        <span 
                          key={index}
                          className="bg-sky-cyan/10 text-sky-cyan border border-sky-cyan/30 text-sm px-3 py-1 rounded-full font-inter"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                
                {/* Student Info & Actions */}
                <div>
                  {/* Student */}
                  <div className="flex items-center mb-6">
                    <img 
                      src={currentProject.studentImage}
                      alt={currentProject.student}
                      className="w-12 h-12 rounded-full object-cover border-2 border-sky-cyan mr-4"
                    />
                    <div>
                      <p className="font-montserrat font-semibold text-steel-navy">
                        {currentProject.student}
                      </p>
                      <p className="font-inter text-sm text-charcoal-gray/60">
                        TRIAD Academy Graduate
                      </p>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex space-x-4">
                    <a 
                      href={currentProject.demo}
                      className="flex-1 bg-sky-cyan text-steel-navy font-montserrat font-semibold py-3 rounded-xl glow-cyan-hover transition-all duration-300 hover:scale-105 text-center inline-flex items-center justify-center space-x-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Live Demo</span>
                    </a>
                    <a 
                      href={currentProject.github}
                      className="flex-1 border-2 border-steel-navy text-steel-navy font-montserrat font-semibold py-3 rounded-xl hover:bg-steel-navy hover:text-white transition-all duration-300 text-center inline-flex items-center justify-center space-x-2"
                    >
                      <Github className="w-4 h-4" />
                      <span>Source</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Navigation Buttons */}
          <button 
            onClick={prevProject}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 w-14 h-14 bg-white rounded-full shadow-xl border-2 border-frost-gray flex items-center justify-center text-steel-navy hover:text-sky-cyan hover:border-sky-cyan glow-cyan-hover transition-all duration-300"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button 
            onClick={nextProject}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 w-14 h-14 bg-white rounded-full shadow-xl border-2 border-frost-gray flex items-center justify-center text-steel-navy hover:text-sky-cyan hover:border-sky-cyan glow-cyan-hover transition-all duration-300"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
        
        {/* Pagination Dots */}
        <div className="flex justify-center space-x-3 mt-8">
          {featuredProjects.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-4 h-4 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'bg-sky-cyan scale-125 glow-cyan' 
                  : 'bg-frost-gray hover:bg-sky-cyan/50'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
