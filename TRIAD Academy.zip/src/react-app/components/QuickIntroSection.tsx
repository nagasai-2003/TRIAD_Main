import { Link } from 'react-router';
import PyramidIcon from './PyramidIcon';

export default function QuickIntroSection() {
  return (
    <section className="py-20 bg-arctic-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              Your Gateway to AI and Future Tech.
            </h2>
            <p className="font-inter text-lg text-charcoal-gray mb-8 leading-relaxed">
              TRIAD Academy bridges the gap between traditional education and industry demands. 
              We empower students with cutting-edge coding skills, AI knowledge, and the mindset 
              to innovate in an ever-evolving tech landscape.
            </p>
            <Link to="/about" className="inline-block bg-sky-cyan text-steel-navy font-montserrat font-semibold px-8 py-4 rounded-2xl text-lg glow-cyan-hover transition-all duration-300 hover:scale-105">
              Discover Our Story
            </Link>
          </div>
          
          {/* Visual */}
          <div className="flex justify-center items-center">
            <div className="relative">
              {/* Large animated pyramid */}
              <PyramidIcon className="w-48 h-48" animated={true} />
              
              {/* Floating tech icons */}
              <div className="absolute -top-8 -left-8 bg-frost-gray rounded-full p-3 animate-bounce">
                <span className="text-steel-navy font-mono text-sm">AI</span>
              </div>
              <div className="absolute -top-8 -right-8 bg-frost-gray rounded-full p-3 animate-bounce" style={{ animationDelay: '0.5s' }}>
                <span className="text-steel-navy font-mono text-sm">ML</span>
              </div>
              <div className="absolute -bottom-8 left-4 bg-frost-gray rounded-full p-3 animate-bounce" style={{ animationDelay: '1s' }}>
                <span className="text-steel-navy font-mono text-sm">{'</>'}</span>
              </div>
              
              {/* Glow effect */}
              <div className="absolute inset-0 bg-sky-cyan/10 rounded-full blur-xl scale-150"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
