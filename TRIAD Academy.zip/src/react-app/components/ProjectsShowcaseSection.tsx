export default function ProjectsShowcaseSection() {
  const projects = [
    {
      title: "AI Chatbot Assistant",
      tech: "Python, TensorFlow, NLP",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=300&fit=crop",
      student: "Sarah Chen"
    },
    {
      title: "Smart Traffic System",
      tech: "Java, Computer Vision, IoT",
      image: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=400&h=300&fit=crop",
      student: "Marcus Rodriguez"
    },
    {
      title: "Quantum Algorithm Simulator",
      tech: "C++, Quantum Computing",
      image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=300&fit=crop",
      student: "Aisha Patel"
    },
    {
      title: "Blockchain Voting App",
      tech: "Python, Cryptography, Web3",
      image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=400&h=300&fit=crop",
      student: "David Kim"
    },
    {
      title: "AR Learning Platform",
      tech: "Unity, C#, ARCore",
      image: "https://images.unsplash.com/photo-1592478411213-6153e4ebc696?w=400&h=300&fit=crop",
      student: "Elena Vasquez"
    },
    {
      title: "ML Stock Predictor",
      tech: "Python, Pandas, Scikit-learn",
      image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=300&fit=crop",
      student: "James Thompson"
    }
  ];

  return (
    <section className="py-20 bg-frost-gray">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
            Learn by Building. Build by Creating.
          </h2>
          <p className="font-montserrat font-semibold text-xl text-sky-cyan mb-4">
            Real projects, real skills.
          </p>
          <p className="font-inter text-lg text-charcoal-gray max-w-2xl mx-auto">
            Students showcase their growth through live coding work that solves real-world problems.
          </p>
        </div>
        
        {/* Projects Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div 
              key={index}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl glow-cyan-hover transition-all duration-300 cursor-pointer fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Project Image */}
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-steel-navy/0 group-hover:bg-steel-navy/20 transition-colors duration-300"></div>
              </div>
              
              {/* Project Info */}
              <div className="p-6">
                <h3 className="font-montserrat font-bold text-xl text-steel-navy mb-2 group-hover:text-sky-cyan transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="font-inter text-sm text-charcoal-gray mb-3">
                  By {project.student}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.split(', ').map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="bg-frost-gray text-steel-navy text-xs px-3 py-1 rounded-full font-inter"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Hover Glow */}
              <div className="absolute inset-0 bg-sky-cyan/0 group-hover:bg-sky-cyan/5 transition-colors duration-300 pointer-events-none"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
