import { useState } from 'react';
import { ExternalLink, Github, Star } from 'lucide-react';

export default function ProjectShowcaseGrid() {
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);

  const projects = [
    {
      id: 1,
      title: "AI Chatbot for Customer Support",
      description: "Intelligent customer service bot using natural language processing to handle inquiries 24/7 with 95% accuracy.",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=300&fit=crop",
      techStack: ["Python", "NLP", "Flask", "TensorFlow"],
      category: "AI & ML",
      student: "Sarah Chen",
      github: "#",
      demo: "#",
      featured: true
    },
    {
      id: 2,
      title: "Smart Traffic Management System",
      description: "IoT-powered traffic optimization system that reduces congestion by 30% using real-time data analysis.",
      image: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=400&h=300&fit=crop",
      techStack: ["Java", "Computer Vision", "IoT", "React"],
      category: "Systems",
      student: "Marcus Rodriguez",
      github: "#",
      demo: "#",
      featured: false
    },
    {
      id: 3,
      title: "Quantum Algorithm Simulator",
      description: "Visual quantum computing simulator for educational purposes, making complex concepts accessible.",
      image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=300&fit=crop",
      techStack: ["C++", "Quantum Computing", "WebGL"],
      category: "Future Tech",
      student: "Aisha Patel",
      github: "#",
      demo: "#",
      featured: true
    },
    {
      id: 4,
      title: "Blockchain Voting Platform",
      description: "Secure, transparent voting system using blockchain technology to ensure election integrity.",
      image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=400&h=300&fit=crop",
      techStack: ["Python", "Cryptography", "Web3", "Solidity"],
      category: "Future Tech",
      student: "David Kim",
      github: "#",
      demo: "#",
      featured: false
    },
    {
      id: 5,
      title: "AR Learning Platform",
      description: "Immersive augmented reality educational app that transforms traditional learning experiences.",
      image: "https://images.unsplash.com/photo-1592478411213-6153e4ebc696?w=400&h=300&fit=crop",
      techStack: ["Unity", "C#", "ARCore", "Firebase"],
      category: "Web Apps",
      student: "Elena Vasquez",
      github: "#",
      demo: "#",
      featured: true
    },
    {
      id: 6,
      title: "ML Stock Price Predictor",
      description: "Machine learning model that predicts stock prices with 87% accuracy using historical data patterns.",
      image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=300&fit=crop",
      techStack: ["Python", "Pandas", "Scikit-learn", "FastAPI"],
      category: "AI & ML",
      student: "James Thompson",
      github: "#",
      demo: "#",
      featured: false
    },
    {
      id: 7,
      title: "Social Media Analytics Dashboard",
      description: "Real-time social media monitoring and analytics platform with sentiment analysis capabilities.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop",
      techStack: ["React", "Node.js", "MongoDB", "Chart.js"],
      category: "Web Apps",
      student: "Priya Sharma",
      github: "#",
      demo: "#",
      featured: false
    },
    {
      id: 8,
      title: "Neural Network Visualizer",
      description: "Interactive tool for visualizing and understanding how neural networks learn and make decisions.",
      image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=300&fit=crop",
      techStack: ["JavaScript", "D3.js", "TensorFlow.js"],
      category: "AI & ML",
      student: "Alex Johnson",
      github: "#",
      demo: "#",
      featured: true
    },
    {
      id: 9,
      title: "Distributed File Storage System",
      description: "Scalable distributed storage system with redundancy and encryption for secure file management.",
      image: "https://images.unsplash.com/photo-1518432031352-d6fc5c10da5a?w=400&h=300&fit=crop",
      techStack: ["Go", "Docker", "Kubernetes", "gRPC"],
      category: "Systems",
      student: "Chen Wei",
      github: "#",
      demo: "#",
      featured: false
    }
  ];

  return (
    <section className="py-20 bg-frost-gray">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
            Student Project Showcase
          </h2>
          <p className="font-inter text-lg text-charcoal-gray max-w-2xl mx-auto">
            Explore the innovative solutions built by our students, from AI applications to quantum computing simulations.
          </p>
        </div>
        
        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div 
              key={project.id}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-lg border border-frost-gray hover:border-sky-cyan glow-cyan-hover transition-all duration-300 cursor-pointer fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* Project Image */}
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                
                {/* Featured Badge */}
                {project.featured && (
                  <div className="absolute top-4 right-4 bg-sky-cyan text-steel-navy px-3 py-1 rounded-full text-sm font-montserrat font-semibold flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-current" />
                    <span>Featured</span>
                  </div>
                )}
                
                {/* Hover Overlay */}
                <div className={`absolute inset-0 bg-steel-navy/90 flex items-center justify-center transition-opacity duration-300 ${
                  hoveredProject === project.id ? 'opacity-100' : 'opacity-0'
                }`}>
                  <div className="flex space-x-4">
                    <a 
                      href={project.github}
                      className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-steel-navy hover:bg-sky-cyan transition-colors duration-300"
                    >
                      <Github className="w-5 h-5" />
                    </a>
                    <a 
                      href={project.demo}
                      className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-steel-navy hover:bg-sky-cyan transition-colors duration-300"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              </div>
              
              {/* Project Info */}
              <div className="p-6">
                {/* Student & Category */}
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xs font-inter text-charcoal-gray/60">
                    By {project.student}
                  </span>
                  <span className="bg-frost-gray text-steel-navy text-xs px-2 py-1 rounded-full font-inter">
                    {project.category}
                  </span>
                </div>
                
                {/* Title */}
                <h3 className="font-montserrat font-bold text-xl text-steel-navy mb-3 group-hover:text-sky-cyan transition-colors duration-300">
                  {project.title}
                </h3>
                
                {/* Description */}
                <p className="font-inter text-sm text-charcoal-gray mb-4 leading-relaxed">
                  {project.description}
                </p>
                
                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2">
                  {project.techStack.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="bg-sky-cyan/10 text-sky-cyan border border-sky-cyan/20 text-xs px-3 py-1 rounded-full font-inter font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Bottom hover gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-sky-cyan/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </div>
          ))}
        </div>
        
        {/* Load More Button */}
        <div className="text-center mt-12 fade-in">
          <button className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-8 py-4 rounded-2xl text-lg glow-cyan-hover transition-all duration-300 hover:scale-105">
            Load More Projects
          </button>
        </div>
      </div>
    </section>
  );
}
