import { Link } from 'react-router';
import { Mail, Phone, MapPin, Github, Twitter, Linkedin, Youtube } from 'lucide-react';

export default function Footer() {
  const navigationLinks = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Courses', href: '/courses' },
    { name: 'Projects', href: '/projects' },
    { name: 'Why TRIAD', href: '/why-triad' },
    { name: 'Blog', href: '#' },
    { name: 'Contact', href: '/contact' }
  ];

  const socialLinks = [
    { icon: <Github className="w-5 h-5" />, href: '#', label: 'GitHub' },
    { icon: <Twitter className="w-5 h-5" />, href: '#', label: 'Twitter' },
    { icon: <Linkedin className="w-5 h-5" />, href: '#', label: 'LinkedIn' },
    { icon: <Youtube className="w-5 h-5" />, href: '#', label: 'YouTube' }
  ];

  return (
    <footer className="bg-steel-navy text-arctic-white">
      <div className="max-w-6xl mx-auto px-6 py-16">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand Section */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <img 
                src="https://mocha-cdn.com/0199154f-3e6d-7595-b23c-85f864415d25/Triad-Academy-Logo-Only-Transparent.png"
                alt="TRIAD Academy Logo"
                className="w-10 h-10"
              />
              <h3 className="font-montserrat font-bold text-2xl text-sky-cyan">
                TRIAD Academy
              </h3>
            </div>
            <p className="font-inter text-arctic-white/80 leading-relaxed mb-6">
              Think. Train. Transform. Empowering the next generation of innovators 
              with cutting-edge coding education and AI-ready skills.
            </p>
            
            {/* Newsletter Signup */}
            <div>
              <h4 className="font-montserrat font-semibold text-lg mb-3">
                Stay Updated
              </h4>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-3 rounded-l-xl bg-arctic-white/10 border border-arctic-white/20 text-arctic-white placeholder-arctic-white/60 focus:outline-none focus:border-sky-cyan font-inter"
                />
                <button className="bg-sky-cyan text-steel-navy px-6 py-3 rounded-r-xl font-montserrat font-semibold glow-cyan-hover transition-all duration-300 hover:scale-105">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="font-montserrat font-semibold text-lg mb-6 text-sky-cyan">
              Quick Links
            </h4>
            <ul className="space-y-3">
              {navigationLinks.map((link, index) => (
                <li key={index}>
                  {link.href.startsWith('/') ? (
                    <Link 
                      to={link.href}
                      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                      className="font-inter text-arctic-white/80 hover:text-sky-cyan transition-colors duration-300"
                    >
                      {link.name}
                    </Link>
                  ) : (
                    <a 
                      href={link.href}
                      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                      className="font-inter text-arctic-white/80 hover:text-sky-cyan transition-colors duration-300"
                    >
                      {link.name}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h4 className="font-montserrat font-semibold text-lg mb-6 text-sky-cyan">
              Contact Us
            </h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-sky-cyan" />
                <span className="font-inter text-arctic-white/80">
                  hello@triadacademy.com
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-sky-cyan" />
                <span className="font-inter text-arctic-white/80">
                  +1 (555) 123-TRIAD
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-sky-cyan" />
                <span className="font-inter text-arctic-white/80">
                  Global Learning Network
                </span>
              </div>
            </div>
            
            {/* Social Links */}
            <div className="mt-6">
              <h5 className="font-montserrat font-semibold mb-3">Follow Us</h5>
              <div className="flex space-x-3">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 bg-arctic-white/10 rounded-lg flex items-center justify-center text-arctic-white hover:bg-sky-cyan hover:text-steel-navy transition-all duration-300 border border-arctic-white/20 hover:border-sky-cyan"
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Footer */}
        <div className="border-t border-arctic-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="font-inter text-arctic-white/60 text-sm">
              © 2024 TRIAD Academy. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="font-inter text-arctic-white/60 hover:text-sky-cyan transition-colors duration-300">
                Privacy Policy
              </a>
              <a href="#" className="font-inter text-arctic-white/60 hover:text-sky-cyan transition-colors duration-300">
                Terms of Service
              </a>
              <a href="#" className="font-inter text-arctic-white/60 hover:text-sky-cyan transition-colors duration-300">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
