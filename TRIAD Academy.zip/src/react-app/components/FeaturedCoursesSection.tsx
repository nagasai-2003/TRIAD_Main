import { Link } from 'react-router';
import { Code, Brain, Zap } from 'lucide-react';

export default function FeaturedCoursesSection() {
  const courses = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Python Programming",
      description: "Build foundations with real projects. Master the language that powers AI, web development, and data science.",
      features: ["Hands-on Projects", "Industry Standards", "Real Applications"]
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Java & C",
      description: "Problem-solving and CS mastery. Develop algorithmic thinking and system-level programming skills.",
      features: ["Algorithm Design", "System Programming", "CS Fundamentals"]
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "AI & Future Tech",
      description: "ML, Quantum, and emerging technologies. Prepare for tomorrow's innovations today.",
      features: ["Machine Learning", "Quantum Computing", "Future Skills"]
    }
  ];

  return (
    <section className="py-20 bg-arctic-white">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
            Featured Courses
          </h2>
          <p className="font-inter text-lg text-charcoal-gray max-w-2xl mx-auto">
            Transform your potential into expertise with our carefully crafted curriculum
          </p>
        </div>
        
        {/* Course Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {courses.map((course, index) => (
            <div 
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl glow-cyan-hover transition-all duration-300 border border-frost-gray fade-in group cursor-pointer"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              {/* Icon */}
              <div className="mb-6 text-sky-cyan group-hover:scale-110 transition-transform duration-300">
                {course.icon}
              </div>
              
              {/* Title */}
              <h3 className="font-montserrat font-bold text-2xl text-steel-navy mb-4">
                {course.title}
              </h3>
              
              {/* Description */}
              <p className="font-inter text-charcoal-gray mb-6 leading-relaxed">
                {course.description}
              </p>
              
              {/* Features */}
              <ul className="space-y-2">
                {course.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-charcoal-gray">
                    <div className="w-2 h-2 bg-sky-cyan rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        {/* CTA Button */}
        <div className="text-center fade-in">
          <Link to="/courses" className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-8 py-4 rounded-2xl text-lg glow-cyan-hover transition-all duration-300 hover:scale-105 inline-block">
            See All Courses
          </Link>
        </div>
      </div>
    </section>
  );
}
