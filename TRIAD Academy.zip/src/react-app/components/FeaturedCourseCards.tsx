const courses = [
  {
    category: 'Foundations',
    title: 'Python Programming',
    description: 'Learn syntax, logic, and build real projects with Python. Perfect for beginners starting their coding journey.',
    duration: '8 weeks',
    level: 'Beginner',
    icon: '🐍'
  },
  {
    category: 'Foundations', 
    title: 'Java & C',
    description: 'Master problem-solving and build a strong computer science foundation with these fundamental languages.',
    duration: '12 weeks',
    level: 'Beginner',
    icon: '☕'
  },
  {
    category: 'Computer Science',
    title: 'Data Structures & Algorithms',
    description: 'Career-defining coding skills that every software engineer needs. Master DSA with hands-on practice.',
    duration: '16 weeks',
    level: 'Intermediate',
    icon: '📊'
  },
  {
    category: 'Computer Science',
    title: 'Networks & Systems',
    description: 'Understand modern computing essentials from networking protocols to system architecture.',
    duration: '10 weeks',
    level: 'Intermediate',
    icon: '🌐'
  },
  {
    category: 'AI & Future Tech',
    title: 'Artificial Intelligence & Machine Learning',
    description: 'Build real AI models and understand the technology shaping our future. Hands-on ML projects included.',
    duration: '20 weeks',
    level: 'Advanced',
    icon: '🤖'
  },
  {
    category: 'AI & Future Tech',
    title: 'Quantum Computing Basics',
    description: 'Explore the next frontier of technology. Learn quantum principles and programming for the future.',
    duration: '14 weeks',
    level: 'Advanced',
    icon: '⚛️'
  }
];

function CourseCard({ course }: { course: typeof courses[0] }) {
  return (
    <div className="bg-arctic-white rounded-2xl p-8 shadow-lg hover:shadow-2xl hover:shadow-sky-cyan/20 transition-all duration-300 hover:scale-105 group border border-frost-gray/50">
      {/* Course Icon */}
      <div className="text-6xl mb-6 text-center group-hover:scale-110 transition-transform duration-300">
        {course.icon}
      </div>
      
      {/* Course Title */}
      <h3 className="font-montserrat font-bold text-2xl text-steel-navy mb-4 text-center">
        {course.title}
      </h3>
      
      {/* Description */}
      <p className="font-inter text-charcoal-gray mb-6 leading-relaxed text-center">
        {course.description}
      </p>
      
      {/* Duration and Level Tags */}
      <div className="flex justify-center gap-3 mb-6">
        <span className="bg-frost-gray text-charcoal-gray px-3 py-1 rounded-full text-sm font-inter">
          {course.duration}
        </span>
        <span className="bg-frost-gray text-charcoal-gray px-3 py-1 rounded-full text-sm font-inter">
          {course.level}
        </span>
      </div>
      
      {/* CTA Button */}
      <div className="text-center">
        <button className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-6 py-3 rounded-xl glow-cyan-hover transition-all duration-300 hover:scale-105">
          Enroll Now
        </button>
      </div>
    </div>
  );
}

export default function FeaturedCourseCards() {
  return (
    <section className="bg-arctic-white py-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
            Featured Courses
          </h2>
          <p className="font-inter text-xl text-charcoal-gray max-w-3xl mx-auto">
            Choose from our carefully crafted curriculum designed to take you from beginner to expert
          </p>
        </div>
        
        {/* Course Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <CourseCard key={index} course={course} />
          ))}
        </div>
      </div>
    </section>
  );
}
