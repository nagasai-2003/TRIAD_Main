import CoursesHeroSection from '@/react-app/components/CoursesHeroSection';
import CategoryFilters from '@/react-app/components/CategoryFilters';
import FeaturedCourseCards from '@/react-app/components/FeaturedCourseCards';
import LearningPathways from '@/react-app/components/LearningPathways';
import WhyOurCourses from '@/react-app/components/WhyOurCourses';
import CoursesCTASection from '@/react-app/components/CoursesCTASection';
import Footer from '@/react-app/components/Footer';

export default function Courses() {
  return (
    <div className="min-h-screen">
      <CoursesHeroSection />
      <CategoryFilters />
      <FeaturedCourseCards />
      <LearningPathways />
      <WhyOurCourses />
      <CoursesCTASection />
      <Footer />
    </div>
  );
}
