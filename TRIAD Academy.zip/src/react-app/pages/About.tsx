import { useState, useEffect } from 'react';
import { Code, Brain, Zap, Users, Globe, Award, ChevronDown } from 'lucide-react';
import PyramidIcon from '@/react-app/components/PyramidIcon';
import Footer from '@/react-app/components/Footer';

export default function About() {
  const [activeLayer, setActiveLayer] = useState<number | null>(null);
  const [visibleMilestones, setVisibleMilestones] = useState<number[]>([]);

  // Timeline milestones
  const milestones = [
    {
      title: "Foundation",
      year: "2020",
      description: "Started with coding fundamentals - C, Java, Python. Building strong foundations for future innovators.",
      icon: <Code className="w-6 h-6" />
    },
    {
      title: "Growth", 
      year: "2022",
      description: "Expanded into CS projects, AI fundamentals, and real-world problem-solving methodologies.",
      icon: <Brain className="w-6 h-6" />
    },
    {
      title: "Future",
      year: "2024",
      description: "Pioneering Quantum Computing, Future Tech, and global expansion to shape tomorrow's leaders.",
      icon: <Zap className="w-6 h-6" />
    }
  ];

  // Pyramid layers
  const pyramidLayers = [
    {
      title: "Future Peak",
      subtitle: "AI, ML, Quantum, Innovation",
      description: "Advanced technologies and innovation-driven skills for tomorrow's challenges",
      level: "top"
    },
    {
      title: "Growth",
      subtitle: "Real Projects, Career Focus",
      description: "Hands-on experience with industry-relevant projects and career guidance",
      level: "middle"
    },
    {
      title: "Foundations",
      subtitle: "Coding Basics, Problem-Solving",
      description: "Strong fundamentals in programming languages and computational thinking",
      level: "base"
    }
  ];

  // Mentors data
  const mentors = [
    {
      name: "Dr. Sarah Chen",
      expertise: "AI & Machine Learning",
      quote: "Every breakthrough starts with curiosity and proper guidance.",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&crop=face"
    },
    {
      name: "Prof. Michael Rodriguez",
      expertise: "Quantum Computing",
      quote: "The future belongs to those who understand quantum possibilities.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face"
    },
    {
      name: "Elena Vasquez",
      expertise: "Software Engineering",
      quote: "Clean code is not just about syntax - it's about thinking clearly.",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=300&fit=crop&crop=face"
    },
    {
      name: "Dr. James Thompson",
      expertise: "Data Science & Analytics",
      quote: "Data tells stories that change the world.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face"
    }
  ];

  // Scroll animation for timeline
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0');
            setVisibleMilestones(prev => [...prev, index]);
          }
        });
      },
      { threshold: 0.5 }
    );

    const milestoneElements = document.querySelectorAll('.milestone');
    milestoneElements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen">
      {/* 1. Hero Section */}
      <section className="relative min-h-screen bg-gradient-to-br from-steel-navy via-steel-navy to-blue-900 flex items-center justify-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-sky-cyan/10 to-transparent"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
          {/* Animated Pyramid Stack */}
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <PyramidIcon className="w-48 h-48" animated={true} />
              <div className="absolute inset-0 animate-pulse bg-sky-cyan/10 rounded-full blur-2xl"></div>
            </div>
          </div>
          
          {/* Hero Content */}
          <h1 className="font-montserrat font-bold text-5xl md:text-7xl text-arctic-white mb-6 fade-in">
            From Basics to Breakthroughs.
          </h1>
          
          <p className="font-montserrat font-semibold text-xl md:text-2xl text-sky-cyan mb-12 fade-in">
            We exist to shape the future of learning, one student at a time.
          </p>
          
          <button className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-10 py-5 rounded-2xl text-xl glow-cyan-hover transition-all duration-300 hover:scale-105 fade-in">
            Explore Our Vision
          </button>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-8 h-8 text-sky-cyan" />
        </div>
      </section>

      {/* 2. Vision & Mission */}
      <section className="py-20 bg-arctic-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            {/* Text Content */}
            <div className="fade-in">
              <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-8">
                Our Vision & Mission
              </h2>
              
              <div className="mb-8">
                <h3 className="font-montserrat font-semibold text-2xl text-sky-cyan mb-4">Vision</h3>
                <p className="font-inter text-lg text-charcoal-gray leading-relaxed">
                  To become a global leader in tech education, preparing students for future-ready careers 
                  through immersive learning and innovation.
                </p>
              </div>
              
              <div>
                <h3 className="font-montserrat font-semibold text-2xl text-sky-cyan mb-4">Mission</h3>
                <p className="font-inter text-lg text-charcoal-gray leading-relaxed">
                  Empower students, job seekers, and professionals with coding, AI, and advanced 
                  technologies — bridging the gap between education and industry.
                </p>
              </div>
            </div>
            
            {/* Futuristic Illustration */}
            <div className="relative flex justify-center items-center">
              <div className="relative">
                <div className="w-80 h-80 bg-gradient-to-br from-sky-cyan/20 to-steel-navy/20 rounded-full flex items-center justify-center">
                  <div className="w-60 h-60 bg-gradient-to-br from-sky-cyan/30 to-steel-navy/30 rounded-full flex items-center justify-center">
                    <div className="w-40 h-40 bg-sky-cyan/40 rounded-full flex items-center justify-center">
                      <Globe className="w-20 h-20 text-steel-navy" />
                    </div>
                  </div>
                </div>
                
                {/* Orbiting elements */}
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-8 h-8 bg-sky-cyan rounded-full animate-pulse"></div>
                </div>
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2">
                  <div className="w-6 h-6 bg-steel-navy rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
                </div>
                <div className="absolute left-0 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-4 h-4 bg-sky-cyan rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
                </div>
                <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2">
                  <div className="w-5 h-5 bg-steel-navy rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Our Journey (Timeline) */}
      <section className="py-20 bg-frost-gray">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              The TRIAD Story
            </h2>
            <p className="font-inter text-lg text-charcoal-gray">
              Our journey from coding fundamentals to future tech innovation
            </p>
          </div>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-sky-cyan/30"></div>
            
            {milestones.map((milestone, index) => (
              <div 
                key={index}
                className={`milestone relative flex items-center mb-16 ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
                data-index={index}
              >
                {/* Content */}
                <div className={`w-5/12 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                  <div className={`bg-white rounded-2xl p-6 shadow-lg transition-all duration-500 ${
                    visibleMilestones.includes(index) ? 'opacity-100 translate-y-0 glow-cyan' : 'opacity-50 translate-y-8'
                  }`}>
                    <div className="flex items-center mb-4 justify-center">
                      <div className="text-sky-cyan mr-3">
                        {milestone.icon}
                      </div>
                      <span className="font-montserrat font-bold text-2xl text-steel-navy">
                        {milestone.year}
                      </span>
                    </div>
                    <h3 className="font-montserrat font-bold text-xl text-steel-navy mb-3">
                      {milestone.title}
                    </h3>
                    <p className="font-inter text-charcoal-gray">
                      {milestone.description}
                    </p>
                  </div>
                </div>
                
                {/* Timeline node */}
                <div className="absolute left-1/2 transform -translate-x-1/2 z-10">
                  <div className={`w-4 h-4 rounded-full transition-all duration-500 ${
                    visibleMilestones.includes(index) ? 'bg-sky-cyan glow-cyan scale-150' : 'bg-frost-gray'
                  }`}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Interactive Pyramid Metaphor */}
      <section className="py-20 bg-arctic-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              The Pyramid Metaphor
            </h2>
            <p className="font-inter text-lg text-charcoal-gray">
              Our learning journey from foundation to future mastery
            </p>
          </div>
          
          <div className="flex flex-col lg:flex-row items-center gap-12">
            {/* Interactive Pyramid Visual */}
            <div className="lg:w-1/2 relative">
              <div className="relative w-80 h-80 mx-auto">
                {/* Pyramid layers */}
                <div 
                  className={`absolute bottom-0 left-1/2 transform -translate-x-1/2 w-80 h-24 bg-gradient-to-r from-sky-cyan/30 to-steel-navy/30 cursor-pointer transition-all duration-300 ${
                    activeLayer === 2 ? 'glow-cyan scale-105' : 'hover:glow-cyan'
                  }`}
                  style={{ clipPath: 'polygon(10% 100%, 90% 100%, 80% 0%, 20% 0%)' }}
                  onClick={() => setActiveLayer(activeLayer === 2 ? null : 2)}
                >
                </div>
                <div 
                  className={`absolute bottom-20 left-1/2 transform -translate-x-1/2 w-60 h-20 bg-gradient-to-r from-sky-cyan/50 to-steel-navy/50 cursor-pointer transition-all duration-300 ${
                    activeLayer === 1 ? 'glow-cyan scale-105' : 'hover:glow-cyan'
                  }`}
                  style={{ clipPath: 'polygon(15% 100%, 85% 100%, 75% 0%, 25% 0%)' }}
                  onClick={() => setActiveLayer(activeLayer === 1 ? null : 1)}
                >
                </div>
                <div 
                  className={`absolute bottom-36 left-1/2 transform -translate-x-1/2 w-40 h-16 bg-gradient-to-r from-sky-cyan/70 to-steel-navy/70 cursor-pointer transition-all duration-300 ${
                    activeLayer === 0 ? 'glow-cyan scale-105' : 'hover:glow-cyan'
                  }`}
                  style={{ clipPath: 'polygon(20% 100%, 80% 100%, 70% 0%, 30% 0%)' }}
                  onClick={() => setActiveLayer(activeLayer === 0 ? null : 0)}
                >
                </div>
              </div>
            </div>
            
            {/* Layer Information */}
            <div className="lg:w-1/2">
              {pyramidLayers.map((layer, index) => (
                <div 
                  key={index}
                  className={`mb-6 p-6 rounded-2xl border-2 transition-all duration-300 cursor-pointer ${
                    activeLayer === index 
                      ? 'border-sky-cyan bg-sky-cyan/5 glow-cyan' 
                      : 'border-frost-gray bg-white hover:border-sky-cyan'
                  }`}
                  onClick={() => setActiveLayer(activeLayer === index ? null : index)}
                >
                  <h3 className="font-montserrat font-bold text-xl text-steel-navy mb-2">
                    {layer.title}
                  </h3>
                  <p className="font-montserrat font-semibold text-sky-cyan mb-3">
                    {layer.subtitle}
                  </p>
                  <p className="font-inter text-charcoal-gray">
                    {layer.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 5. Leadership & Mentors */}
      <section className="py-20 bg-frost-gray">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              Guided by Experts
            </h2>
            <p className="font-inter text-lg text-charcoal-gray mb-4">
              Our mentors are not just teachers — they're industry guides shaping tomorrow's innovators.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {mentors.map((mentor, index) => (
              <div 
                key={index}
                className="group bg-white rounded-2xl p-6 shadow-lg glow-cyan-hover transition-all duration-300 border border-frost-gray fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-center">
                  <img 
                    src={mentor.image}
                    alt={mentor.name}
                    className="w-24 h-24 rounded-full mx-auto mb-4 object-cover border-4 border-frost-gray group-hover:border-sky-cyan transition-colors duration-300"
                  />
                  <h3 className="font-montserrat font-bold text-lg text-steel-navy mb-2 group-hover:text-sky-cyan transition-colors duration-300">
                    {mentor.name}
                  </h3>
                  <p className="font-inter text-sm text-sky-cyan mb-4">
                    {mentor.expertise}
                  </p>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <p className="font-inter text-sm text-charcoal-gray italic">
                      "{mentor.quote}"
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Global Future Focus */}
      <section className="py-20 bg-arctic-white relative overflow-hidden">
        {/* World map watermark */}
        <div className="absolute inset-0 opacity-5">
          <svg viewBox="0 0 1200 600" className="w-full h-full">
            <path d="M200 200 Q300 150 400 180 Q500 170 600 190 Q700 200 800 195 Q900 190 1000 200" 
                  stroke="#1F3C5B" strokeWidth="3" fill="none" />
            <path d="M250 300 Q350 280 450 290 Q550 285 650 295 Q750 300 850 295" 
                  stroke="#1F3C5B" strokeWidth="3" fill="none" />
          </svg>
        </div>
        
        <div className="relative z-10 max-w-6xl mx-auto px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              Shaping Global Tech Leaders.
            </h2>
            <p className="font-inter text-xl text-charcoal-gray max-w-3xl mx-auto leading-relaxed">
              TRIAD is more than an academy — it's a launchpad for innovators, creators, 
              and problem-solvers worldwide.
            </p>
          </div>
          
          {/* Futuristic glowing map */}
          <div className="relative bg-steel-navy rounded-2xl p-12 mb-12">
            <div className="absolute inset-0 bg-gradient-to-r from-sky-cyan/5 via-transparent to-sky-cyan/5"></div>
            
            <div className="relative z-10 grid md:grid-cols-3 gap-8 text-center">
              <div className="group">
                <div className="w-16 h-16 bg-sky-cyan/20 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:bg-sky-cyan/40 transition-colors duration-300">
                  <Users className="w-8 h-8 text-sky-cyan" />
                </div>
                <h3 className="font-montserrat font-bold text-2xl text-sky-cyan mb-2">10,000+</h3>
                <p className="font-inter text-arctic-white">Global Students</p>
              </div>
              
              <div className="group">
                <div className="w-16 h-16 bg-sky-cyan/20 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:bg-sky-cyan/40 transition-colors duration-300">
                  <Globe className="w-8 h-8 text-sky-cyan" />
                </div>
                <h3 className="font-montserrat font-bold text-2xl text-sky-cyan mb-2">50+</h3>
                <p className="font-inter text-arctic-white">Countries Reached</p>
              </div>
              
              <div className="group">
                <div className="w-16 h-16 bg-sky-cyan/20 rounded-full mx-auto mb-4 flex items-center justify-center group-hover:bg-sky-cyan/40 transition-colors duration-300">
                  <Award className="w-8 h-8 text-sky-cyan" />
                </div>
                <h3 className="font-montserrat font-bold text-2xl text-sky-cyan mb-2">95%</h3>
                <p className="font-inter text-arctic-white">Success Rate</p>
              </div>
            </div>
          </div>
          
          <div className="text-center fade-in">
            <button className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-10 py-5 rounded-2xl text-xl glow-cyan-hover transition-all duration-300 hover:scale-105">
              Join the Movement
            </button>
          </div>
        </div>
      </section>

      {/* 7. Closing CTA */}
      <section className="py-20 bg-gradient-to-br from-steel-navy via-steel-navy to-blue-900 relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-r from-sky-cyan/10 via-transparent to-sky-cyan/10"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-montserrat font-bold text-4xl md:text-6xl text-arctic-white mb-12 fade-in">
            Think. Train. Transform.
          </h2>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center fade-in">
            <button className="bg-sky-cyan text-steel-navy font-montserrat font-bold px-10 py-5 rounded-2xl text-xl glow-cyan-hover transition-all duration-300 hover:scale-105">
              Explore Courses
            </button>
            <button className="border-2 border-sky-cyan bg-transparent text-sky-cyan font-montserrat font-semibold px-10 py-5 rounded-2xl text-xl hover:bg-sky-cyan hover:text-steel-navy transition-all duration-300 hover:scale-105">
              Talk to Us
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
