import { useState } from 'react';
import { Mail, Phone, MapPin, Github, Twitter, Linkedin, Youtube, Send, Navigation } from 'lucide-react';
import PyramidIcon from '@/react-app/components/PyramidIcon';
import Footer from '@/react-app/components/Footer';

export default function Contact() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log('Form submitted:', formData);
  };

  const contactDetails = [
    {
      icon: <MapPin className="w-8 h-8" />,
      title: "Address",
      details: "TRIAD Academy Global Hub",
      subDetails: "Innovation District, Tech City"
    },
    {
      icon: <Phone className="w-8 h-8" />,
      title: "Phone",
      details: "+1 (555) 123-TRIAD",
      subDetails: "Mon-Fri 9AM-6PM EST"
    },
    {
      icon: <Mail className="w-8 h-8" />,
      title: "Email",
      details: "hello@triadacademy.com",
      subDetails: "We respond within 24 hours"
    }
  ];

  const socialLinks = [
    { icon: <Linkedin className="w-6 h-6" />, href: '#', label: 'LinkedIn', color: 'hover:text-blue-600' },
    { icon: <Twitter className="w-6 h-6" />, href: '#', label: 'Twitter', color: 'hover:text-blue-400' },
    { icon: <Youtube className="w-6 h-6" />, href: '#', label: 'YouTube', color: 'hover:text-red-600' },
    { icon: <Github className="w-6 h-6" />, href: '#', label: 'GitHub', color: 'hover:text-gray-800' }
  ];

  return (
    <div className="min-h-screen">
      {/* 1. Hero Header */}
      <section className="relative min-h-screen bg-gradient-to-br from-steel-navy via-steel-navy to-blue-900 flex items-center justify-center overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-sky-cyan/10 to-transparent"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
          {/* Animated Pyramid */}
          <div className="mb-8 flex justify-center">
            <PyramidIcon className="w-32 h-32" animated={true} />
          </div>
          
          {/* Main Headline */}
          <h1 className="font-montserrat font-bold text-5xl md:text-7xl text-arctic-white mb-6 fade-in">
            Let's Build Your Future Together.
          </h1>
          
          {/* Subheadline */}
          <p className="font-montserrat font-semibold text-xl md:text-2xl text-sky-cyan mb-12 fade-in">
            Reach out to TRIAD Academy — we're here to guide your journey.
          </p>
          
          {/* Scroll indicator */}
          <div className="animate-bounce">
            <div className="w-8 h-8 border-2 border-sky-cyan rounded-full flex items-center justify-center">
              <div className="w-2 h-2 bg-sky-cyan rounded-full"></div>
            </div>
          </div>
        </div>
        
        {/* Floating code elements */}
        <div className="absolute top-20 left-10 text-sky-cyan/30 font-mono text-sm animate-pulse">
          {'{ connect: true }'}
        </div>
        <div className="absolute bottom-32 right-10 text-sky-cyan/30 font-mono text-sm animate-pulse">
          {'const future = await contact();'}
        </div>
      </section>

      {/* 2. Contact Form */}
      <section className="py-20 bg-arctic-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-frost-gray/30 rounded-2xl p-8 md:p-12 shadow-xl border border-frost-gray">
            {/* Form Header */}
            <div className="text-center mb-12 fade-in">
              <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
                Get in Touch
              </h2>
              <p className="font-inter text-lg text-charcoal-gray">
                Share your goals with us and let's create a personalized learning path for your success.
              </p>
            </div>
            
            {/* Contact Form */}
            <form onSubmit={handleSubmit} className="space-y-6 fade-in">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Full Name */}
                <div>
                  <label htmlFor="fullName" className="block font-montserrat font-semibold text-steel-navy mb-3">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-4 rounded-2xl bg-white border border-frost-gray text-charcoal-gray font-inter focus:outline-none focus:border-sky-cyan focus:ring-2 focus:ring-sky-cyan/20 transition-all duration-300"
                    placeholder="Enter your full name"
                    required
                  />
                </div>
                
                {/* Email */}
                <div>
                  <label htmlFor="email" className="block font-montserrat font-semibold text-steel-navy mb-3">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-4 rounded-2xl bg-white border border-frost-gray text-charcoal-gray font-inter focus:outline-none focus:border-sky-cyan focus:ring-2 focus:ring-sky-cyan/20 transition-all duration-300"
                    placeholder="your.email@example.com"
                    required
                  />
                </div>
              </div>
              
              {/* Phone Number */}
              <div>
                <label htmlFor="phone" className="block font-montserrat font-semibold text-steel-navy mb-3">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="w-full px-4 py-4 rounded-2xl bg-white border border-frost-gray text-charcoal-gray font-inter focus:outline-none focus:border-sky-cyan focus:ring-2 focus:ring-sky-cyan/20 transition-all duration-300"
                  placeholder="+1 (555) 123-4567"
                />
              </div>
              
              {/* Message */}
              <div>
                <label htmlFor="message" className="block font-montserrat font-semibold text-steel-navy mb-3">
                  Message / Query
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={6}
                  className="w-full px-4 py-4 rounded-2xl bg-white border border-frost-gray text-charcoal-gray font-inter focus:outline-none focus:border-sky-cyan focus:ring-2 focus:ring-sky-cyan/20 transition-all duration-300 resize-none"
                  placeholder="Tell us about your goals, questions, or how we can help you on your coding journey..."
                  required
                ></textarea>
              </div>
              
              {/* Submit Button */}
              <div className="text-center">
                <button
                  type="submit"
                  className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-10 py-4 rounded-2xl text-lg glow-cyan-hover transition-all duration-300 hover:scale-105 inline-flex items-center space-x-3 shadow-xl"
                >
                  <Send className="w-5 h-5" />
                  <span>Send Message</span>
                </button>
                
                {/* Microcopy */}
                <p className="font-inter text-sm text-charcoal-gray/60 mt-4">
                  We'll get back to you within 24 hours.
                </p>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* 3. Contact Details */}
      <section className="py-20 bg-frost-gray">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              Quick Access Info
            </h2>
            <p className="font-inter text-lg text-charcoal-gray">
              Multiple ways to connect with our team
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {contactDetails.map((detail, index) => (
              <div 
                key={index}
                className="group bg-white rounded-2xl p-8 text-center shadow-lg border-2 border-frost-gray hover:border-sky-cyan hover:shadow-xl glow-cyan-hover transition-all duration-300 fade-in"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                {/* Icon */}
                <div className="mb-6 flex justify-center">
                  <div className="w-16 h-16 bg-sky-cyan/10 rounded-2xl flex items-center justify-center text-steel-navy group-hover:bg-sky-cyan/20 group-hover:text-sky-cyan transition-all duration-300">
                    {detail.icon}
                  </div>
                </div>
                
                {/* Title */}
                <h3 className="font-montserrat font-bold text-xl text-steel-navy mb-4 group-hover:text-sky-cyan transition-colors duration-300">
                  {detail.title}
                </h3>
                
                {/* Details */}
                <p className="font-inter font-semibold text-charcoal-gray mb-2">
                  {detail.details}
                </p>
                <p className="font-inter text-sm text-charcoal-gray/60">
                  {detail.subDetails}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Map Integration */}
      <section className="py-20 bg-arctic-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16 fade-in">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl text-steel-navy mb-6">
              Find Us
            </h2>
            <p className="font-inter text-lg text-charcoal-gray">
              Visit our global learning hub or connect virtually
            </p>
          </div>
          
          {/* Map Container */}
          <div className="relative rounded-2xl overflow-hidden shadow-xl border border-frost-gray fade-in">
            {/* Placeholder for Map - In a real implementation, you'd use Google Maps embed */}
            <div className="h-96 bg-gradient-to-br from-steel-navy/10 to-sky-cyan/10 flex items-center justify-center relative overflow-hidden">
              {/* Background pattern */}
              <div className="absolute inset-0 opacity-10">
                <svg viewBox="0 0 400 400" className="w-full h-full">
                  <circle cx="200" cy="200" r="150" stroke="#1F3C5B" strokeWidth="2" fill="none" />
                  <circle cx="200" cy="200" r="100" stroke="#00CFFF" strokeWidth="2" fill="none" />
                  <circle cx="200" cy="200" r="50" stroke="#1F3C5B" strokeWidth="2" fill="none" />
                </svg>
              </div>
              
              {/* Map placeholder content */}
              <div className="relative z-10 text-center">
                <div className="w-20 h-20 bg-sky-cyan rounded-full flex items-center justify-center mx-auto mb-4 glow-cyan">
                  <PyramidIcon className="w-12 h-12" animated={false} />
                </div>
                <h3 className="font-montserrat font-bold text-2xl text-steel-navy mb-2">
                  TRIAD Academy Global Hub
                </h3>
                <p className="font-inter text-charcoal-gray mb-6">
                  Innovation District, Tech City
                </p>
                
                {/* Get Directions Button */}
                <button className="bg-sky-cyan text-steel-navy font-montserrat font-semibold px-6 py-3 rounded-xl glow-cyan-hover transition-all duration-300 hover:scale-105 inline-flex items-center space-x-2">
                  <Navigation className="w-5 h-5" />
                  <span>Get Directions</span>
                </button>
              </div>
            </div>
            
            {/* Map overlay info */}
            <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-lg rounded-lg p-4 shadow-lg border border-frost-gray">
              <p className="font-inter text-sm text-charcoal-gray">
                <span className="font-semibold">Open:</span> Mon-Fri 9AM-6PM
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Social & Community Links */}
      <section className="py-20 bg-frost-gray">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="fade-in">
            <h3 className="font-montserrat font-bold text-4xl text-steel-navy mb-6">
              Connect With Us
            </h3>
            <p className="font-inter text-lg text-charcoal-gray mb-12">
              Join our community of innovators across all platforms
            </p>
            
            {/* Social Media Icons */}
            <div className="flex justify-center space-x-8">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className={`group w-16 h-16 bg-white rounded-2xl border-2 border-frost-gray flex items-center justify-center text-steel-navy hover:border-sky-cyan glow-cyan-hover transition-all duration-300 hover:scale-110 ${social.color}`}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. Closing CTA */}
      <section className="py-20 bg-gradient-to-br from-steel-navy via-steel-navy to-blue-900 relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-r from-sky-cyan/10 via-transparent to-sky-cyan/10"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-sky-cyan/5 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          {/* Animated Pyramid */}
          <div className="mb-8 flex justify-center">
            <PyramidIcon className="w-24 h-24" animated={true} />
          </div>
          
          {/* Main Headline */}
          <h2 className="font-montserrat font-bold text-4xl md:text-6xl text-arctic-white mb-6 fade-in">
            Code. Create. Conquer.
          </h2>
          
          {/* Subheadline */}
          <p className="font-inter text-xl text-arctic-white/80 mb-12 max-w-2xl mx-auto leading-relaxed fade-in">
            Your journey starts with a single step — talk to us today.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center fade-in">
            <button className="bg-sky-cyan text-steel-navy font-montserrat font-bold px-10 py-5 rounded-2xl text-xl glow-cyan-hover transition-all duration-300 hover:scale-105 shadow-xl">
              Join TRIAD Today
            </button>
            <button className="border-2 border-sky-cyan bg-transparent text-sky-cyan font-montserrat font-semibold px-10 py-5 rounded-2xl text-xl hover:bg-sky-cyan hover:text-steel-navy transition-all duration-300 hover:scale-105">
              Talk to Us
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
