import ProjectsHeroSection from '@/react-app/components/ProjectsHeroSection';
import ProjectFilters from '@/react-app/components/ProjectFilters';
import ProjectShowcaseGrid from '@/react-app/components/ProjectShowcaseGrid';
import FeaturedProjectsSection from '@/react-app/components/FeaturedProjectsSection';
import StudentShowcaseTestimonials from '@/react-app/components/StudentShowcaseTestimonials';
import ProjectsCTASection from '@/react-app/components/ProjectsCTASection';
import Footer from '@/react-app/components/Footer';

export default function Projects() {
  return (
    <div className="min-h-screen">
      <ProjectsHeroSection />
      <ProjectFilters />
      <ProjectShowcaseGrid />
      <FeaturedProjectsSection />
      <StudentShowcaseTestimonials />
      <ProjectsCTASection />
      <Footer />
    </div>
  );
}
